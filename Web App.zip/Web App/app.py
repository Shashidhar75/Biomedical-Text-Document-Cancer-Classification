# Importing the required libraries
import nltk
import re
import string
import contractions
import pickle
from flask import Flask, render_template, request
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

# Downloading required NLTK resources
nltk.download('punkt')
nltk.download('stopwords')
nltk.download('wordnet')

# Loading the saved model
with open("naive_bayes_model.pkl", "rb") as model_file:
    model = pickle.load(model_file)

# Loading the saved TfidfVectoriser
with open("tfidf_vectorizer.pkl", "rb") as vectorizer_file:
    vectorizer = pickle.load(vectorizer_file)

# Defining class labels
class_labels = {0: "Colon Cancer", 1: "Lung Cancer", 2: "Thyroid Cancer"}

# Initialising Flask app
app = Flask(__name__)

# Preprocessing function
def preprocess_text(text):
    """
    This function preprocesses the input text by performing the following steps like it
    Converts text to lowercase, Expands contractions, Removes URLs, punctuation and non-alphanumeric characters,
    Tokenises the text, Removes stopwords, Lemmatises the words and also Removes numeric values.
    
    Parameters:
    text : input text to be preprocessed
    
    Returns:
    str: cleaned and preprocessed text
    """
    # Convert text to lowercase and expand contractions
    text = text.lower()
    text = contractions.fix(text)
    # Remove URLs, punctuation and non-alphanumeric characters
    text = re.sub(r"http\S+|www\S+", "", text)
    text = text.translate(str.maketrans("", "", string.punctuation))
    text = re.sub(r"[^a-zA-Z0-9\s]", "", text)
    # Tokenise the text into words
    words = word_tokenize(text)
    stop_words = set(stopwords.words("english"))
    # Lemmatise each word and remove stopwords
    lemmatizer = WordNetLemmatizer()
    text = " ".join([lemmatizer.lemmatize(word) for word in words if word not in stop_words])
    # Remove numbers
    text = re.sub(r'\d+', '', text)  
    return text

@app.route("/", methods=["GET", "POST"])
def index():
    """
    This function route for the web application homepage. Handles both GET and POST requests.
    On POST, it takes user input, preprocesses the text and predicts the cancer type.
    
    Returns:
    str: rendered HTML page with the prediction result
    """
    prediction = None
    if request.method == "POST":
        # Gets text input from the user
        user_text = request.form["user_text"]
        # Preprocess the user input text
        cleaned_text = preprocess_text(user_text)
        # Vectorise cleaned text using the TfidfVectorizer
        vectorized_text = vectorizer.transform([cleaned_text])
        # Predicts cancer type using the Naive Bayes model
        predicted_index = model.predict(vectorized_text)[0]
         # Maps predicted index to the corresponding class label
        predicted_class = class_labels.get(predicted_index, "Unknown")
        # Formats prediction result for display
        prediction = f"Predicted Cancer Type: {predicted_class}"

    # Renders HTML template and pass prediction to the page
    return render_template("index.html", prediction=prediction)

if __name__ == "__main__":
    app.run(debug=True)
